--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tarif DROP CONSTRAINT tarif_pkey;
ALTER TABLE ONLY public.tagihan DROP CONSTRAINT tagihan_pkey;
ALTER TABLE ONLY public.pengguna DROP CONSTRAINT pengguna_pkey;
ALTER TABLE ONLY public.pembayaran DROP CONSTRAINT pembayaran_pkey;
ALTER TABLE ONLY public.pelanggan DROP CONSTRAINT pelanggan_pkey;
ALTER TABLE ONLY public.level DROP CONSTRAINT level_pkey;
ALTER TABLE ONLY public.admin DROP CONSTRAINT admin_pkey;
DROP TABLE public.tarif;
DROP TABLE public.tagihan;
DROP TABLE public.pengguna;
DROP TABLE public.pembayaran;
DROP TABLE public.pelanggan;
DROP TABLE public.level;
DROP TABLE public.admin;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE admin (
    id_admin character varying(20) NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(100) NOT NULL,
    nama_admin character varying(100) NOT NULL,
    id_level character varying(100) NOT NULL
);


ALTER TABLE admin OWNER TO postgres;

--
-- Name: level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE level (
    id_level character varying(20) NOT NULL,
    nama_level character varying(50) NOT NULL
);


ALTER TABLE level OWNER TO postgres;

--
-- Name: pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pelanggan (
    id_pelanggan character varying(20) NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(100) NOT NULL,
    nomor_kwh integer NOT NULL,
    nama_pelanggan character varying(100) NOT NULL,
    alamat character varying(100) NOT NULL,
    id_tarif character varying(100) NOT NULL
);


ALTER TABLE pelanggan OWNER TO postgres;

--
-- Name: pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pembayaran (
    id_pembayaran character varying(20) NOT NULL,
    id_tagihan character varying(50) NOT NULL,
    id_pelanggan character varying(100) NOT NULL,
    tanggal_pembayaran date NOT NULL,
    bulan_bayar character varying(100) NOT NULL,
    biaya_admin integer NOT NULL,
    total_bayar integer NOT NULL,
    id_admin character varying(100) NOT NULL
);


ALTER TABLE pembayaran OWNER TO postgres;

--
-- Name: pengguna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pengguna (
    id_pengguna character varying(20) NOT NULL,
    id_pelanggan character varying(50) NOT NULL,
    bulan character varying(100) NOT NULL,
    tahun character varying(100) NOT NULL,
    meter_awal character varying(100) NOT NULL,
    meter_akhir character varying(100) NOT NULL
);


ALTER TABLE pengguna OWNER TO postgres;

--
-- Name: tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tagihan (
    id_tagihan character varying(20) NOT NULL,
    id_pengguna character varying(50) NOT NULL,
    id_pelanggan character varying(100) NOT NULL,
    bulan character varying(100) NOT NULL,
    tahun character varying(100) NOT NULL,
    jumlah_meter integer NOT NULL,
    status character varying(100) NOT NULL
);


ALTER TABLE tagihan OWNER TO postgres;

--
-- Name: tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tarif (
    id_tarif character varying(20) NOT NULL,
    daya character varying(50) NOT NULL,
    tarifperkwh character varying(100) NOT NULL
);


ALTER TABLE tarif OWNER TO postgres;

--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY admin (id_admin, username, password, nama_admin, id_level) FROM stdin;
\.
COPY admin (id_admin, username, password, nama_admin, id_level) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY level (id_level, nama_level) FROM stdin;
\.
COPY level (id_level, nama_level) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pelanggan (id_pelanggan, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM stdin;
\.
COPY pelanggan (id_pelanggan, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM stdin;
\.
COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM '$$PATH$$/2832.dat';

--
-- Data for Name: pengguna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pengguna (id_pengguna, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM stdin;
\.
COPY pengguna (id_pengguna, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM '$$PATH$$/2827.dat';

--
-- Data for Name: tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tagihan (id_tagihan, id_pengguna, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tagihan (id_tagihan, id_pengguna, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tarif (id_tarif, daya, tarifperkwh) FROM stdin;
\.
COPY tarif (id_tarif, daya, tarifperkwh) FROM '$$PATH$$/2830.dat';

--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (id_admin);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level
    ADD CONSTRAINT level_pkey PRIMARY KEY (id_level);


--
-- Name: pelanggan pelanggan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan
    ADD CONSTRAINT pelanggan_pkey PRIMARY KEY (id_pelanggan);


--
-- Name: pembayaran pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (id_pembayaran);


--
-- Name: pengguna pengguna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pengguna
    ADD CONSTRAINT pengguna_pkey PRIMARY KEY (id_pengguna);


--
-- Name: tagihan tagihan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan
    ADD CONSTRAINT tagihan_pkey PRIMARY KEY (id_tagihan);


--
-- Name: tarif tarif_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tarif
    ADD CONSTRAINT tarif_pkey PRIMARY KEY (id_tarif);


--
-- PostgreSQL database dump complete
--

